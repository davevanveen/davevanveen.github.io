---
layout: page
title: Page Without Hero
description: This is a page with no hero
hide_hero: true
show_sidebar: false
menubar: example_menu
---

# Page Without Hero

This is a page without a hero.

To hide the hero, set `hide_hero: true` in the page's frontmatter. 

Hiding the hero means that there will not be a title and subtitle displayed, so it will have to be added to the page content. 