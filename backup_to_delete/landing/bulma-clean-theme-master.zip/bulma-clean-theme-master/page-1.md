---
title: Page With Sidebar
subtitle: A demo page with a sidebar
layout: page
show_sidebar: true
---

This is a demo page showing the sidebar.

To show the sidebar set show_sidebar to true in the page's frontmatter.

```yml
title: Page With Sidebar
subtitle: A demo page with a sidebar
layout: page
show_sidebar: true
```