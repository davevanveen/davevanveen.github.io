---
title: Page without sidebar
subtitle: Demo page without the sidebar
layout: page
show_sidebar: false
---

This is another sample page showing how a page can look without a sidebar. 

To hide the sidebar, set the show_sidebar to false in the page's frontmatter

```yml
title: Page without sidebar
subtitle: Demo page without the sidebar
layout: page
show_sidebar: false
```